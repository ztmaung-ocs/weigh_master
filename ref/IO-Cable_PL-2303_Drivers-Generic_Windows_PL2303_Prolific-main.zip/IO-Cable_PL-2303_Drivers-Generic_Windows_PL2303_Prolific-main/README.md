# IO-Cable_PL-2303_Drivers-Generic_Windows_PL2303_Prolific

Ref: https://www.youtube.com/watch?v=Y7JmCKCovMI

Ref: http://wp.brodzinski.net/2014/10/01/fake-pl2303-how-to-install/

I test it on Win10, and it works
